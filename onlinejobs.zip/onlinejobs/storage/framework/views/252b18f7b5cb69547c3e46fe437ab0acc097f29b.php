<?php $__env->startSection('title'); ?>
    Edit vacancy
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

    <section class="content-header">
        <h1>
        Vacancy        <!-- <small>it all starts here</small> -->
        </h1>
        <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li><li class=><a href="">Vacancy</a></li><li class="active">add</li>      </ol>
    </section>

    <?php if(Session::has('status')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('status')); ?>

        </div>
    <?php endif; ?>

    <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-body">
                            <form class="form-horizontal span6" action=<?php echo e(route('vacancies.update', $vacancy->id)); ?> method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <h1 class="page-header">Edit Vacancy</h1>
                                    </div>
                                    <!-- /.col-lg-12 -->
                                </div> 

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "COMPANYNAME">Company Name:</label>
                                        <div class="col-md-8">
                                            <select class="form-control input-sm" id="COMPANYID" name="companyname" required>
                                                <option value="<?php echo e($vacancy->companyname); ?>"><?php echo e($vacancy->companyname); ?></option>
                                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value=<?php echo e($company->name); ?>><?php echo e($company->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for="CATEGORY">Category :</label>

                                        <div class="col-md-8">
                                            <select class="form-control input-sm" id="CATEGORY" name="category" required>
                                                <option value="<?php echo e($vacancy->category); ?>"><?php echo e($vacancy->category); ?></option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option> 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "OCCUPATIONTITLE">Occupation Title:</label> 
                                        <div class="col-md-8">
                                        <input class="form-control input-sm" id="OCCUPATIONTITLE" name="occuptitle" value="<?php echo e($vacancy->occuptitle); ?>" placeholder="Occupation Title"   autocomplete="none" required /> 
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "REQ_NO_EMPLOYEES">Required no. of Employees:</label> 
                                        <div class="col-md-8">
                                            <input class="form-control input-sm" type="number" id="REQ_NO_EMPLOYEES" value="<?php echo e($vacancy->numofemp); ?>" name="numofemp" placeholder="Required no. of Employees"   autocomplete="none" required /> 
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "SALARIES">Salary:</label> 
                                        <div class="col-md-8">
                                            <input class="form-control input-sm" id="SALARIES" name="salary" value="<?php echo e($vacancy->salary); ?>" type="number" placeholder="Salary"   autocomplete="none" required /> 
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "DURATION_EMPLOYEMENT">Duration of Employment:</label> 
                                        <div class="col-md-8">
                                            <input class="form-control input-sm" id="DURATION_EMPLOYEMENT" name="duration" value="<?php echo e($vacancy->duration); ?>" placeholder="Duration of Employment"   autocomplete="none" required /> 
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "QUALIFICATION_WORKEXPERIENCE">Qualification/Work Experience:</label> 
                                        <div class="col-md-8">
                                            <textarea class="form-control input-sm" id="QUALIFICATION_WORKEXPERIENCE" name="experience" value="<?php echo e($vacancy->experience); ?>" placeholder="Qualification/Work Experience"   autocomplete="none" required ><?php echo e($vacancy->experience); ?></textarea> 
                                        </div>
                                    </div>
                                </div> 

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "JOBDESCRIPTION">Job Description:</label> 
                                        <div class="col-md-8">
                                            <textarea class="form-control input-sm" id="JOBDESCRIPTION" name="description" value="<?php echo e($vacancy->description); ?>" placeholder="Job Description"   autocomplete="none" required ><?php echo e($vacancy->description); ?></textarea> 
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "PREFEREDSEX">Prefered Sex:</label> 
                                        <div class="col-md-8">
                                            <select class="form-control input-sm" id="PREFEREDSEX"  name="prefsex" required>
                                                <option value="<?php echo e($vacancy->prefsex); ?>"><?php echo e($vacancy->prefsex); ?></option>
                                                <option>Male</option>
                                                <option>Female</option>
                                                <option>Male/Female</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>  

                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for=
                                        "SECTOR_VACANCY">Sector of Vacancy:</label> 
                                        <div class="col-md-8">
                                            <textarea class="form-control input-sm" id="SECTOR_VACANCY" name="sector" value="<?php echo e($vacancy->sector); ?>" placeholder="Sector of Vacancy"   autocomplete="none" required><?php echo e($vacancy->sector); ?></textarea> 
                                        </div>
                                    </div>
                                </div>   
                                
                                <div class="form-group">
                                    <div class="col-md-8">
                                        <label class="col-md-4 control-label" for="idno"></label>  

                                        <div class="col-md-8">
                                            <button class="btn btn-primary btn-sm" name="save" type="submit" ><span class="fa fa-save fw-fa"></span> Save</button></a>
                                        </div>
                                    </div>
                                </div> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/editvacancy.blade.php ENDPATH**/ ?>