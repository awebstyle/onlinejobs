<?php $__env->startSection('title'); ?>
    Search by Title
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="pageTitle">Search for <?php echo e($category); ?></h2>
                </div>
            </div>
        </div>
    </section>

    
      <section id="content">
      <div class="container content"> 
        <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="panel panel-primary">

            <div class="panel-header">
              <div style="border-bottom: 1px solid #ddd;padding: 10px;font-size: 20px;font-weight: bold;color: #000;margin-bottom: 5px;"><a href=<?php echo e(route('vacancies.show', $vacancy->id)); ?>><?php echo e($vacancy->occuptitle); ?></a> 
              </div> 
            </div>

            <div class="panel-body contentbody">
              <div class="col-sm-10">
                <div class="col-sm-12">
                  <p>Qualification/Work Experience :</p>
                    <ul style="list-style: none;"> 
                      <li><?php echo e($vacancy->experience); ?></li> 
                  </ul> 
                </div>

                <div class="col-sm-12"> 
                  <p>Job Description:</p>
                  <ul style="list-style: none;"> 
                        <li><?php echo e($vacancy->description); ?></li> 
                  </ul> 
                </div>

                <div class="col-sm-12">
                  <p>Employer :  <?php echo e($vacancy->companyname); ?></p>
                  <p>Location :  
                      <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($company->name == $vacancy->companyname): ?>
                          <?php echo e($company->address); ?>

                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </p>
                                                                                                                                                                                                              </div>

              </div>

              <div class="col-sm-2"> 
                <a href=<?php echo e(route('applynow', $vacancy->id)); ?> class="btn btn-main btn-next-tab">Apply Now !</a>
              </div>

            </div> 
          
            <div class="panel-footer">
                Date Posted :  <?php echo e($vacancy->created_at); ?>             
            </div>

          </div>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/jobbycategory.blade.php ENDPATH**/ ?>