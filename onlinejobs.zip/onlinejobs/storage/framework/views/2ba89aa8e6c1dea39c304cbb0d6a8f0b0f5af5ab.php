<?php $__env->startSection('title'); ?>
    Edit category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>Category</h1>
        <ol class="breadcrumb">
          <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
          <li class=><a href="dashboard.html">Category</a></li>
          <li class="active">Edit</li>      
        </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
                <form class="form-horizontal span6" action=<?php echo e(route('categories.update', $category->id)); ?> method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    
                    <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Edit Category</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                    </div> 

                    <div class="form-group">
                    <div class="col-md-8">
                        <label class="col-md-4 control-label" for=
                        "CATEGORY">Category:</label>

                        <div class="col-md-8">
                        <input class="form-control input-sm" id="CATEGORY" name="category" placeholder=
                            "Category" type="text" value="<?php echo e($category->category); ?>">
                        </div>
                    </div>
                    </div>

                    <div class="form-group">
                    <div class="col-md-8">
                        <label class="col-md-4 control-label" for=
                        "idno"></label>
                        <div class="col-md-8">
                        <button class="btn btn-primary btn-sm" name="save" type="submit" ><span class="fa fa-save fw-fa"></span> Save</button>
                        </div>
                    </div>
                    </div> 

                    <div class="form-group">
                    <div class="rows">
                        <div class="col-md-6">
                        <label class="col-md-6 control-label" for="otherperson"></label>
                        <div class="col-md-6">
                        </div>
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                    </div>
                    
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/editcategory.blade.php ENDPATH**/ ?>