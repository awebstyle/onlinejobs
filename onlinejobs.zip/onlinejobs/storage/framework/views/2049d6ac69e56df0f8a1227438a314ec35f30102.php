<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href=<?php echo e(asset("bootstrap/css/bootstrap.min.css")); ?>>
    <!-- Font Awesome -->
    <link rel="stylesheet" href=<?php echo e(asset("plugins/font-awesome/css/font-awesome.min.css")); ?>>
    <!-- Theme style -->
    <link rel="stylesheet" href=<?php echo e(asset("dist/css/AdminLTE.min.css")); ?>>
    <!-- AdminLTE Skins. Choose a skin from the css/skins
            folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href=<?php echo e(asset("dist/css/skins/_all-skins.min.css")); ?>>
    <!-- iCheck -->
    <link rel="stylesheet" href=<?php echo e(asset("plugins/iCheck/flat/blue.css")); ?>>
    <!-- Morris chart -->
    <link rel="stylesheet" href=<?php echo e(asset("plugins/morris/morris.css")); ?>>
    <!-- jvectormap -->
    <link rel="stylesheet" href=<?php echo e(asset("plugins/jvectormap/jquery-jvectormap-1.2.2.css")); ?>>
    <!-- Date Picker -->
    <link href=<?php echo e(asset("plugins/datepicker/bootstrap-datetimepicker.min.css")); ?> rel="stylesheet" media="screen">

    <link rel="stylesheet" href=<?php echo e(asset("plugins/dataTables/jquery.dataTables.min.css")); ?>>  
    <link rel="stylesheet" href=<?php echo e(asset("plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css")); ?>>
</head><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/template/partials/_head.blade.php ENDPATH**/ ?>