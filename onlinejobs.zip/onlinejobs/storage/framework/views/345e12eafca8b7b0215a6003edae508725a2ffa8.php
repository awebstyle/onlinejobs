<?php $__env->startSection('title'); ?>
    Application success
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="pageTitle">Success</h2>
                </div>
            </div>
        </div>
    </section>
        
    <section id="content">
        <div class="container content">  
            <div class="alert alert-success alert-dismissible clearfix">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <div class="mg-alert-icon"><i class="fa fa-check"></i></div>
                    <?php if(Session::has('status')): ?>
                        <h3 class="mg-alert-payment"><?php echo e(Session::get('status')); ?></h3>
                    <?php endif; ?>
                </div>
        </div>
    </section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/success.blade.php ENDPATH**/ ?>