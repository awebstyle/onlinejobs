<footer>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <div class="widget">
                                    <h5 class="widgetheading">Our Contact</h5>
                                    <address>
                                    <strong>Our Company</strong><br>
                                    JC Main Road, Near Silnile tower<br>
                                    Pin-21542 NewYork US.</address>
                                    <p>
                                        <i class="icon-phone"></i> (123) 456-789 - 1255-12584 <br>
                                        <i class="icon-envelope-alt"></i> jannopalacios@gmail.com
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="widget">
                                    <h5 class="widgetheading">Quick Links</h5>
                                    <ul class="link-list">
                                        <li><a href="">Home</a></li>
                                        <li><a href="">Company</a></li>
                                        <li><a href="">Hiring</a></li>
                                        <li><a href="">About us</a></li>
                                        <li><a href="">Contact us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="widget">
                                    <h5 class="widgetheading">Latest posts</h5>
                                    <ul class="link-list">
                                        <li><a href="">URC/ Accounting</a></li> 
                                        <li><a href="">URC/ ISD</a></li> 
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div id="sub-footer">
                        <div class="container">
                            <div class="row">

                                <div class="col-lg-6">
                                    <div class="copyright">
                                        <p>
                                            <span>&copy; CampCodes 2021 All right reserved.  
                                        </p>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <ul class="social-network">
                                        <li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                        <li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                </footer>  <?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/template/partials/_footer.blade.php ENDPATH**/ ?>