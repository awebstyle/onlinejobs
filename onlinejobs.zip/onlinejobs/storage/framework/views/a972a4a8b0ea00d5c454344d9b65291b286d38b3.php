<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
        <!-- javascript ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.easing.1.3.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/bootstrap.min.js")); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset("plugins/dataTables/dataTables.bootstrap.min.js")); ?> ></script>  
        <script src=<?php echo e(asset("plugins/datatables/jquery.dataTables.min.js")); ?>></script> 
        <script type="text/javascript" src=<?php echo e(asset("plugins/datepicker/bootstrap-datepicker.js")); ?> charset="UTF-8"></script>
        <script type="text/javascript" src=<?php echo e(asset("plugins/datepicker/bootstrap-datetimepicker.js")); ?> charset="UTF-8"></script>
        <script type="text/javascript" src=<?php echo e(asset("plugins/datepicker/locales/bootstrap-datetimepicker.uk.js")); ?> charset="UTF-8"></script>
        <script type="text/javascript" language="javascript" src=<?php echo e(asset("plugins/input-mask/jquery.inputmask.js")); ?>></script> 
        <script type="text/javascript" language="javascript" src=<?php echo e(asset("plugins/input-mask/jquery.inputmask.date.extensions.js")); ?>></script> 
        <script type="text/javascript" language="javascript" src=<?php echo e(asset("plugins/input-mask/jquery.inputmask.extensions.js")); ?>></script> 
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.fancybox.pack.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.fancybox-media.js")); ?>></script>  
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.flexslider.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/animate.js")); ?>></script>
        <!-- Vendor Scripts -->
        <script src=<?php echo e(asset("plugins/home-plugins/js/modernizr.custom.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.isotope.min.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/jquery.isotope.min.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/animate.js")); ?>></script>
        <script src=<?php echo e(asset("plugins/home-plugins/js/custom.js")); ?>></script> 
        <script src=<?php echo e(asset("plugins/home-plugins/js/script.js")); ?>></script>     
    <?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/template/partials/_scripts.blade.php ENDPATH**/ ?>