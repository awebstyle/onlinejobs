<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="" />
        <meta name="author" content="http://webthemez.com" />
        <!-- css -->
        <link href=<?php echo e(asset("plugins/home-plugins/css/bootstrap.min.css")); ?> rel="stylesheet" />
        <link href=<?php echo e(asset("plugins/home-plugins/css/fancybox/jquery.fancybox.css")); ?> rel="stylesheet"> 
        <link href=<?php echo e(asset("plugins/home-plugins/css/flexslider.css")); ?> rel="stylesheet" /> 
        <link href=<?php echo e(asset("plugins/home-plugins/css/style.css")); ?> rel="stylesheet" />
        <!-- <link rel="stylesheet" href="plugins/dataTables/dataTables.bootstrap.css">  --> 
        <link rel="stylesheet" href=<?php echo e(asset("plugins/font-awesome/css/font-awesome.min.css")); ?>> 

        <link rel="stylesheet" href=<?php echo e(asset("plugins/dataTables/jquery.dataTables.min.css")); ?>> 
        <link rel="stylesheet" href=<?php echo e(asset("plugins/dataTables/jquery.dataTables_themeroller.css")); ?>> 
        <!-- datetime picker CSS -->
        <link href=<?php echo e(asset("plugins/datepicker/bootstrap-datetimepicker.min.css")); ?> rel="stylesheet" media="screen">
        <link href=<?php echo e(asset("plugins/datepicker/datepicker3.css")); ?> rel="stylesheet" media="screen">
    </head>

    <?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/template/partials/_head.blade.php ENDPATH**/ ?>