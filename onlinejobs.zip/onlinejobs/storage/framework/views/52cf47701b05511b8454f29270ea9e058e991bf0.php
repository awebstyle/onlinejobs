<?php $__env->startSection('title'); ?>
    Vacancies
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
          Vacancy        <!-- <small>it all starts here</small> -->
        </h1>
        <ol class="breadcrumb">
          <li><a href="admin"><i class="fa fa-dashboard"></i> Home</a></li><li class=>Vacancy</li>      </ol>
    </section>

    <?php if(Session::has('status')): ?>
      <div class="alert alert-success">
        <?php echo e(Session::get('status')); ?>

      </div>
    <?php endif; ?>

    <section class="content">

      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
                            <div class="row">
                <div class="col-lg-12">
                  <h1 class="page-header">List of Vacancies  <a href=<?php echo e(route('vacancies.create')); ?> class="btn btn-primary btn-xs  ">  <i class="fa fa-plus-circle fw-fa"></i> Add Job Vacancy</a>  </h1>
                </div>
              <!-- /.col-lg-12 -->
              </div>

                <form action="controller.php?action=delete" Method="POST">  	
                  <div class="table-responsive">					
                    <table id="dash-table" class="table table-striped table-bordered table-hover"  style="font-size:12px" cellspacing="0">
                    
                      <thead>
                        <tr>

                          <!-- <th>No.</th> -->
                          <th>Company Name</th> 
                          <th>Occupation Title</th> 
                          <th>Require no. of Employees</th> 
                          <th>Salaries</th> 
                          <th>Duration of Employment</th> 
                          <th>Qualification/Work experience</th> 
                          <th>Job Description</th> 
                          <th>Prefered Sex</th> 
                          <th>Sector of Vacancy</th> 
                          
                          <th width="10%">Action</th>
                        </tr>	
                      </thead> 
                      <tbody>
                        <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($vacancy->companyname); ?></td>
                            <td><?php echo e($vacancy->occuptitle); ?></td>
                            <td><?php echo e($vacancy->numofemp); ?></td>
                            <td><?php echo e($vacancy->salary); ?></td>
                            <td><?php echo e($vacancy->duration); ?></td>
                            <td><?php echo e($vacancy->experience); ?></td>
                            <td><?php echo e($vacancy->description); ?></td>
                            <td><?php echo e($vacancy->prefsex); ?></td>
                            <td><?php echo e($vacancy->sector); ?></td>
                            <td style="display: flex; justify-content: space-around;">
                              <a title="Edit" href=<?php echo e(route('vacancies.edit', $vacancy->id)); ?> class="btn btn-primary btn-xs  ">  <span class="fa fa-edit fw-fa"></a>
                             <form method="POST" action=<?php echo e(route('vacancies.destroy', $vacancy->id)); ?>>
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('delete'); ?>
                                  <button type="sumbit" class="btn btn-danger btn-xs"><span class="fa fa-trash-o fw-fa"></span></button>
                              </form> 
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                      </tbody>
                    </table>
                  <div class="btn-group">
              <!--  <a href="index.php?view=add" class="btn btn-default">New</a> -->
                        </div>
            
            
                </form>

              <div class="table-responsive">	  
              </div>
            </div>
          </div>
        </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/vacancies.blade.php ENDPATH**/ ?>