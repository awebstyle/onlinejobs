<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.3.2
    </div>
    <strong>Copyright &copy; 2021 <a href="#">CampCodes</a>.</strong> All rights
    reserved.
</footer> <?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/template/partials/_footer.blade.php ENDPATH**/ ?>