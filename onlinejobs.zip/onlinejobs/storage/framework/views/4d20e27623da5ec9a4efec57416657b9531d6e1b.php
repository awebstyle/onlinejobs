<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu"> 
            <li  class="<?php echo e(request()->is('adminhome') ? 'active' : ''); ?>" >
                <a href=<?php echo e(route('adminhome')); ?>>
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>  
                </a> 
            </li> 
            <li class="<?php echo e(request()->is('companies.index') || request()->is('addcompany') ? 'active' : ''); ?>" >
                <a href=<?php echo e(route('companies.index')); ?>>
                    <i class="fa fa-building"></i> <span>Company</span> 
                </a>
            </li>
            <li class="<?php echo e(request()->is('vacancies.index') || request()->is('addvacancy') ? 'active' : ''); ?>" >
                <a href=<?php echo e(route('vacancies.index')); ?>>
                    <i class="fa fa-suitcase"></i> <span>Vacancy</span> 
                </a>
            </li>
            <li class="<?php echo e(request()->is('employees.index') || request()->is('addemployee') ? 'active' : ''); ?>" >
                <a href=<?php echo e(route('employees.index')); ?>>
                    <i class="fa fa-users"></i> <span>Employee</span> 
                </a>
            </li> 
            <li class="<?php echo e(request()->is('applicants.index') ? 'active' : ''); ?>" > 
                <a href=<?php echo e(route('applicants.index')); ?>>
                    <i class="fa fa-users"></i>
                    <span>Applicants</span> 
                    <span class="label label-primary pull-right">0</span>
                </a>
            </li> 
            <li class="<?php echo e(request()->is('categories.index') || request()->is('addcategory') ? 'active' : ''); ?>" > 
                <a href=<?php echo e(route('categories.index')); ?>>
                    <i class="fa fa-list"></i> <span>Category</span>  
                </a>
            </li>      
            <li class="<?php echo e(request()->is('adminusers') || request()->is('adduser') ? 'active' : ''); ?>">
                <a href=<?php echo e(route('adminusers')); ?>>
                    <i class="fa fa-user"></i> <span>Manage Users</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/template/partials/_sidebar.blade.php ENDPATH**/ ?>