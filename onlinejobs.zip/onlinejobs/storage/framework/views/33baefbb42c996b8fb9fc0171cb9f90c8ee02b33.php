 <div style="min-height: 30px;"></div>

 <div class="navbar navbar-default navbar-static-top" > 
    <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href=<?php echo e(route('home')); ?>>Website Name</a>
            </div>

            <div class="navbar-collapse collapse ">
                <ul class="nav navbar-nav">
                    <li class="<?php echo e(request()->is('home') ? 'active' : ''); ?>"><a href=<?php echo e(route('home')); ?>>Home</a></li> 
                    <li class="dropdown <?php echo e(request()->is('advancedsearch') ? 'active' : ''); ?>">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Job Search <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li class=""><a href=<?php echo e(route('advancedsearch')); ?>>Advance Search</a></li>
                            <li><a href=<?php echo e(route('jobbycompany')); ?>>Job By Company</a></li>
                            <li><a href=<?php echo e(route('jobbyfunction')); ?>>Job By Function</a></li>
                            <li><a href=<?php echo e(route('jobbytitle')); ?>>Job By Title</a></li>
                        </ul>
                    </li> 
                    <li class="dropdown <?php echo e(request()->is('jobbycategory') ? 'active' : ''); ?>">
                    <a href="#" data-toggle="dropdown" class="dropdown-toggle">Popular Jobs <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href=<?php echo e(route('jobbycategory', $category->category)); ?>><?php echo e($category->category); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                    </li> 
                    <li class="<?php echo e(request()->is('company') ? 'active' : ''); ?>"><a href=<?php echo e(route('company')); ?>>Company</a></li>
                    <li class="<?php echo e(request()->is('hiring') ? 'active' : ''); ?>"><a href=<?php echo e(route('hiring')); ?>>Hiring Now</a></li>
                    <li class="<?php echo e(request()->is('about') ? 'active' : ''); ?>"><a href=<?php echo e(route('about')); ?>>About Us</a></li>
                    <li class="<?php echo e(request()->is('contactus') ? 'active' : ''); ?>"><a href=<?php echo e(route('contactus')); ?>>Contact</a></li>
                </ul>
            </div>
        </div>
    </div><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/template/partials/_navbar.blade.php ENDPATH**/ ?>