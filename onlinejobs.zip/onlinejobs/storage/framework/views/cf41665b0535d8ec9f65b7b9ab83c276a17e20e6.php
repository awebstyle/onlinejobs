
<?php echo $__env->make('front.template.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div id="wrapper" class="home-page">

            <!-- start header -->
                <?php echo $__env->make('front.template.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
            <!-- end header --> 

            <!-- start Modal -->
                <?php echo $__env->make('front.template.partials._modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          
            <!-- end Modal -->   
       
            <!-- start content -->
                <?php echo $__env->yieldContent('content'); ?>
            <!-- end content -->

            <!-- start footer -->
                <?php echo $__env->make('front.template.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          
            <!-- end footer -->
            
        </div>
                
        <?php echo $__env->make('front.template.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/template/index.blade.php ENDPATH**/ ?>