<?php echo $__env->make('admin.template.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body class="hold-transition skin-blue fixed sidebar-mini">

    <div class="wrapper">

        <!-- start header -->
        <?php echo $__env->make('admin.template.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header -->

        <!-- start modal -->
        <?php echo $__env->make('admin.template.partials._modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end modal -->

        <!-- left sidebar -->
        <?php echo $__env->make('admin.template.partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end sidebar -->            

        <!-- start content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- end content -->

        <!-- start footer -->
        <?php echo $__env->make('admin.template.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end footer -->

    </div>
        
    <?php echo $__env->make('admin.template.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
</body>

</html>
<?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/template/index.blade.php ENDPATH**/ ?>