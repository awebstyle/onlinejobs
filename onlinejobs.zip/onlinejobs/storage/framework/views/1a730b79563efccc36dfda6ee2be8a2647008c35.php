<?php $__env->startSection('title'); ?>
    Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="pageTitle">Company</h2>
                </div>
            </div>
        </div>
    </section>

    <section id="content">
        <div class="container content">     
            <!-- Service Blcoks -->  
            <div class="row">
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 info-blocks">
                        <i class="icon-info-blocks fa fa-building-o"></i>
                        <div class="info-blocks-in">
                            
                            <h3><a href=<?php echo e(route('hiringcompany', [$company->id])); ?>><?php echo e($company->name); ?></a></h3>
                            <!-- <p>weqwe</p> -->
                            <p>Address : <?php echo e($company->address); ?></p>
                            <p>Contact No. : <?php echo e($company->contact); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div> 
        </div>
    </section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/company.blade.php ENDPATH**/ ?>