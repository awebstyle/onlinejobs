<header>
    <div class="topbar navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">      
                    <p class="pull-left hidden-xs">
                        <i class="fa fa-phone"></i>Tel No. (+001) 123-456-789
                    </p>
                        <?php if(Session::has('client')): ?>
                            
                            <p class="pull-right login">
                                <a title="View Notification(s)" href=""> <i class="fa fa-bell-o"></i> <span class="label label-success">2</span></a> | 
                                        
                                <a title="View Message(s)" href=""> <i class="fa fa-envelope-o"></i> <span class="label label-success">1</span></a> | 
                                        
                                <a title="View Profile" href=<?php echo e(route('profile', Session::get('client')->id)); ?>> <i class="fa fa-user"></i> Howdy, <?php echo e(Session::get('client')->firstname); ?></a> | 
                                        
                                <a href=<?php echo e(route('signout')); ?>>  <i class="fa fa-sign-out"> </i>Logout</a> 
                                        
                            </p>
                        <?php else: ?>
                            <p   class="pull-right login">
                                <a data-target="#myModal" data-toggle="modal" href=""> <i class="fa fa-lock"></i> Login </a>
                            </p> 
                        <?php endif; ?>

                </div>
            </div>
        </div>
    </div> 

    <?php echo $__env->make('front.template.partials._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header> <?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/template/partials/_header.blade.php ENDPATH**/ ?>