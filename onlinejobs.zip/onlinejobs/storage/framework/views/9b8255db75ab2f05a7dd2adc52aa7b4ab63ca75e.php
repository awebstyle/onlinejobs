<?php $__env->startSection('title'); ?>
    Submit app
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="pageTitle">Submit Application</h2>
                </div>
            </div>
        </div>
    </section>

    <?php if(Session::has('client')): ?>
        <section id="content">
            <div class="container content">     
                <p> </p>     
                <form class="form-horizontal span6  wow fadeInDown" action="<?php echo e(route('submit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="col-sm-8"> 
                        <div class="row">
                            <h2 class=" ">Personal Info</h2>          
                            <div class="form-group">
                                <div class="col-md-11">
                                <label class="col-md-4 control-label" for=
                                    "FNAME">Firstname:</label>
                            
                                    <div class="col-md-8">
                                        <input class="form-control input-sm" id="FNAME" name="firstname" placeholder="Firstname" type="text" value=<?php echo e(Session::get('client')->firstname); ?> autocomplete="off" readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "LNAME">Lastname:</label>
                            
                                    <div class="col-md-8">
                                        <input  class="form-control input-sm" id="LNAME" name="lastname" placeholder="Lastname" value=<?php echo e(Session::get('client')->lastname); ?>  autocomplete="off" readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "MNAME">Middle Name:</label>
                            
                                    <div class="col-md-8">
                                        <input  class="form-control input-sm" id="MNAME" name="middlename" placeholder=
                                        "Middle Name" value=<?php echo e(Session::get('client')->middlename); ?> autocomplete="off" readonly>
                                    </div>
                                </div>
                            </div> 

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "ADDRESS">Address:</label>
                            
                                    <div class="col-md-8">
                                        <textarea class="form-control input-sm" id="ADDRESS" name="address" placeholder=
                                        "Address" type="text" value=<?php echo e(Session::get('client')->address); ?> readonly autocomplete="off"><?php echo e(Session::get('client')->address); ?></textarea>
                                    </div>
                                </div>
                            </div> 

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "Gender">Sex:</label>
                                        <div class="col-md-8">
                                            <div class="col-lg-5">
                                                <div class="radio">
                                                    <?php if(Session::get('client')->gender == 'Female'): ?>
                                                        <label><input id="optionsRadios1"  checked="true" name="gender" type="radio" value="Female" readonly>Female</label>
                                                    <?php else: ?>
                                                        <label><input id="optionsRadios1"  name="gender" type="radio" value="Female" readonly>Female</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                    
                                            <div class="col-lg-4">
                                                <div class="radio">
                                                    <?php if(Session::get('client')->gender == 'Male'): ?>
                                                        <label><input id="optionsRadios2" checked="true" name="gender" type="radio" value="Male" readonly> Male</label>
                                                    <?php else: ?>
                                                        <label><input id="optionsRadios2" name="gender" type="radio" value="Male" readonly> Male</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div> 
                                        </div> 
                                    
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "BIRTHPLACE">
                                        Date of Birth:
                                    </label>
                            
                                    <div class="col-md-8">
                                        <input type="date" name="" id="" class="form-control input-sm" value=<?php echo e(Session::get('client')->dateofbirth); ?> readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "BIRTHPLACE">Place of Birth:</label>
                            
                                    <div class="col-md-8">
                                        <textarea class="form-control input-sm" id="BIRTHPLACE" name="birthplace" value=<?php echo e(Session::get('client')->birthplace); ?> placeholder="Place of Birth" type="text" autocomplete="off" readonly><?php echo e(Session::get('client')->birthplace); ?>

                                        </textarea>
                                    </div>
                                </div>
                            </div> 

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "TELNO">Contact No.:</label>
                                
                                    <div class="col-md-8">
                                        <input class="form-control input-sm" id="TELNO" name="phone" placeholder=
                                        "Contact No." type="text" any value=<?php echo e(Session::get('client')->phone); ?> readonly autocomplete="off">
                                    </div>
                                </div>
                            </div> 

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "CIVILSTATUS">Civil Status:</label>
                                
                                    <div class="col-md-8">
                                        <select class="form-control input-sm" name="civilstatus" id="CIVILSTATUS" readonly >
                                            <option value=<?php echo e(Session::get('client')->civilstatus); ?> >Single</option>
                                        </select> 
                                    </div>
                                </div>
                            </div>  
                            
                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "EMAILADDRESS">Email Address:</label> 
                                    <div class="col-md-8">
                                        <input type="email" class="form-control input-sm" id="EMAILADDRESS" name="email" placeholder="Email Address"   autocomplete="false" value=<?php echo e(Session::get('client')->email); ?> readonly/> 
                                    </div>
                                </div>
                            </div>  

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "USERNAME">Username:</label>
                                
                                    <div class="col-md-8">
                                        <input  class="form-control input-sm" id="USERNAME" name="username" placeholder="Username" value=<?php echo e(Session::get('client')->username); ?> autocomplete="off" readonly>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "PASS">Password:</label>
                                
                                    <div class="col-md-8">
                                    <input  class="form-control input-sm" id="PASS" name="password" placeholder="Password" type="password" value=<?php echo e(Session::get('client')->password); ?> autocomplete="off" readonly>
                                    </div>
                                </div>
                            </div> 

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "DEGREE">Educational Attainment:</label>
                                
                                    <div class="col-md-8">
                                        <input  class="form-control input-sm" id="DEGREE" name="degree" placeholder="Educational Attainment" value=<?php echo e(Session::get('client')->degree); ?> autocomplete="off" readonly>
                                    </div>
                                </div>
                            </div> 

                            <div class="form-group">
                                <div class="col-md-11">
                                    <label class="col-md-4 control-label" for=
                                    "d"></label>  
                                
                                    <div class="col-md-8">
                                        <label><input type="checkbox" required> By Sign up you are agree with our <a href="#">terms and condition</a></label>
                                    
                                    </div>
                                </div>
                            </div>   
            
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="row">
                            <h2 class=" " >Job Details</h2>
                            <div class="panel">

                                <div class="panel-header">
                                    <div style="border-bottom: 1px solid #ddd;padding: 10px;font-size: 25px;font-weight: bold;color: #000;margin-bottom: 5px;"><a href=""><?php echo e($vacancy->occuptitle); ?></a> 
                                    </div> 
                                </div>

                                <div class="panel-body">
                                        <div class="row contentbody">
                                                <div class="col-sm-6">
                                                    <ul>
                                                        <li><i class="fp-ht-bed"></i>Required No. of Employee's : <?php echo e($vacancy->numofemp); ?></li>
                                                        <li><i class="fp-ht-food"></i>Salary : <?php echo e($vacancy->salary); ?></li>
                                                        <li><i class="fa fa-sun-"></i>Duration of Employment : <?php echo e($vacancy->duration); ?></li>
                                                    </ul>
                                                </div>
                                                <div class="col-sm-6">
                                                    <ul> 
                                                        <li><i class="fp-ht-tv"></i>Prefered Sex : <?php echo e($vacancy->prefsex); ?></li>
                                                        <li><i class="fp-ht-computer"></i>Sector of Vacancy : <?php echo e($vacancy->sector); ?></li>
                                                    </ul>
                                                </div>
                                                <div class="col-sm-12">
                                                    <p>Qualification/Work Experience :</p>
                                                    <ul style="list-style: none;"> 
                                                        <li><?php echo e($vacancy->experience); ?></li> 
                                                    </ul> 
                                                </div>
                                                <div class="col-sm-12"> 
                                                    <p>Job Description:</p>
                                                    <ul style="list-style: none;"> 
                                                        <li><?php echo e($vacancy->description); ?></li> 
                                                    </ul> 
                                                </div>
                                                <div class="col-sm-12">
                                                    <p>Employer :  <?php echo e($vacancy->companyname); ?></p> 
                                                    <p>
                                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($company->name == $vacancy->companyname): ?>
                                                                Location :  <?php echo e($company->address); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </p>
                                                </div>
                                            </div>
                                </div>
                                
                                <div class="panel-footer">
                                    Date Posted :  <?php echo e($vacancy->created_at); ?> 
                                </div>
                            </div>  
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="row">
                            <div class="panel panel-default">
                                <div class="panel-header">
                                    <div style="border-bottom: 1px solid #ddd;padding: 10px;font-size: 25px;font-weight: bold;color: #000;margin-bottom: 5px;">Attach your Resume here.
                                    </div>
                                </div>
                                <div class="panel-body"> 
                                    <label class="col-md-2" for="picture" style="padding: 0;margin: 0;">Attachtment File:</label> 
                                    <div class="col-md-10" style="padding: 0;margin: 0;">
                                        <input id="picture" name="resume" type="file" required>
                                        <input type="hidden" name="vacancyid" value="<?php echo e($vacancy->id); ?>">
                                        <input type="hidden" name="clientid" value="<?php echo e(Session::get('client')->id); ?>">
                                        <input type="hidden" name="companyname" value="<?php echo e($vacancy->companyname); ?>">
                                        <input type="hidden" name="occuptitle" value="<?php echo e($vacancy->occuptitle); ?>">
                                    </div> 
                                </div>
                            </div> 
                        </div> 
                    </div>
                    <div class="form-group">
                        <div class="col-md-12"> 
                            <button class="btn btn-primary btn-sm pull-right" name="submit" type="submit" >Submit <span class="fa fa-arrow-right"></span></button>
                        <a href="" class="btn btn-info"><span class="fa fa-arrow-left"></span>&nbsp;<strong>Back</strong></a> 
                        </div>
                    </div>   
                </form> 
            </div> 
        </section> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/submit.blade.php ENDPATH**/ ?>