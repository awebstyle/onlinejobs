<?php $__env->startSection('title'); ?>
    Hiring Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="pageTitle">Hiring In <?php echo e($company->name); ?></h2>
            </div>
        </div>
    </div>
</section>

<section id="content">
    <div class="container content">     
        <!-- Service Blocks -->    
        <table id="dash-table" class="table table-hover">
            <thead>
                <th>Job Title</th>
                <th>Company</th>
                <th>Location</th>
                <th>Date Posted</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href=<?php echo e(route('vacancies.show', $vacancy->id)); ?>><?php echo e($vacancy->occuptitle); ?></a></td>
                        <td><?php echo e($company->name); ?></td>
                        <td><?php echo e($company->address); ?></td>
                        <td><?php echo e($vacancy->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>   
    </div>
</section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/front/hiringcompany.blade.php ENDPATH**/ ?>