<?php $__env->startSection('title'); ?>
    Add a Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

    <section class="content-header">
        <h1>Company</h1>
        <ol class="breadcrumb">
          <li><a href="dashboard.html"><i class="fa fa-dashboard"></i> Home</a></li><li class=><a href="dashboard.html">Company</a></li><li class="active">add</li>      
        </ol>
    </section>

    
     
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">         
              <form class="form-horizontal span6" action=<?php echo e(route('companies.update', $company->id)); ?> method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                  <div class="row">
                    <div class="col-lg-12">
                      <h1 class="page-header">Edit Company</h1>
                    </div>
                  </div> 
                  <br>

                               
                  <div class="form-group">
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "COMPANYNAME">Company Name:</label>

                      <div class="col-md-8">
                        <input class="form-control input-sm" id="COMPANYNAME" placeholder=
                            "Company Name" type="text" value="<?php echo e($company->name); ?>" autocomplete="none" name="name" required>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                  
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "COMPANYADDRESS">Company Address:</label> 
                      <div class="col-md-8">
                        <textarea class="form-control input-sm" id="COMPANYADDRESS" placeholder="Company Address" type="text" value="" required  onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off" name="address"><?php echo e($company->address); ?></textarea>
                      </div>
                    </div>
                  </div> 

                  <div class="form-group">
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "COMPANYCONTACTNO">Company Contact No.:</label>

                      <div class="col-md-8">
                        <input class="form-control input-sm" id="COMPANYCONTACTNO" placeholder=
                            "Company Contact No." type="text" value="<?php echo e($company->contact); ?>" autocomplete="none"   name="contact" required>
                      </div>
                    </div>
                  </div>  

                  <div class="form-group">
                    <div class="col-md-8">
                      <label class="col-md-4 control-label" for=
                      "idno"></label>  

                      <div class="col-md-8">
                        <button class="btn btn-primary btn-sm" name="update" type="submit" ><span class="fa fa-save fw-fa"></span> Update</button>
                    </div>
                    </div>
                  </div> 
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/onlinejobs/onlinejobs/resources/views/admin/editcompany.blade.php ENDPATH**/ ?>